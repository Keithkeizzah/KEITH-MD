module.exports = async (context) => {
        const { client, m, dreadedspeed } = context;


await m.reply(`𝖐𝖊𝖎𝖙𝖍 𝖘𝖕𝖊𝖊𝖉\n${dreadedspeed.toFixed(4)}𝐌\𝐒`)

}
